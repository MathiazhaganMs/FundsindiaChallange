import unittest
from selenium import webdriver

class EnvironmentSetup(unittest.TestCase):

    @classmethod
    def setUpClass(self):
        path = "Base\chromedriver"

        self.driver = webdriver.Chrome(path)
        self.driver.get("https://accounts.google.com/signin")
        self.driver.maximize_window()
        self.driver.implicitly_wait(10)

    def tally(self):

        return len(self._resultForDoCleanups.errors) + len(self._resultForDoCleanups.failures)

    @classmethod
    def tearDownClass(self):

        if (self.driver != None):
            self.driver.close()
            self.driver.quit()
