from Locators.locators import Locators
from selenium.webdriver.support.ui import Select
from time import sleep
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait

class LoginPage(object):

    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(self.driver, 40)
        self.login_email_textbox_xpath = Locators.login_email_textbox_xpath
        self.email_next_xpath = Locators.email_next_xpath
        self.login_password_xpath = Locators.login_password_xpath
        self.password_next_xpath = Locators.password_next_xpath
        self.account_username_xpath = Locators.account_username_xpath
        self.account_icon_xpath = Locators.account_icon_xpath
        self.logout_xpath = Locators.logout_xpath
        self.sigin_verify_xpath = Locators.sigin_verify_xpath

    def login_validation(self):
        value = False
        try:
            self.wait.until(EC.presence_of_element_located((By.XPATH, self.login_email_textbox_xpath)))
            self.driver.find_element_by_xpath(self.login_email_textbox_xpath).send_keys("msmathi0207@gmail.com")
            self.driver.find_element_by_xpath(self.email_next_xpath).click()

            self.wait.until(EC.presence_of_element_located((By.XPATH, self.login_password_xpath)))
            self.driver.find_element_by_xpath(self.login_password_xpath).send_keys("Mrcricket@07")
            self.driver.find_element_by_xpath(self.password_next_xpath).click()
            value = True

        except:
            value = False
        return value

    def account_name(self):
        value = False
        # self.driver.get("https://myaccount.google.com/")
        account_name = self.driver.find_element_by_xpath(self.account_username_xpath).text

        if "Mathiazhagan Ms" in account_name:
            value = True

        return value

    def logout_validation(self):
        value = False
        self.driver.find_element_by_xpath(self.account_icon_xpath).click()
        self.driver.find_element_by_xpath(self.logout_xpath).click()
        try:
            ele = self.driver.find_element_by_xpath(self.sigin_verify_xpath)
            if ele.is_displayed():
                value = True
        except:
            value = False
        return value






