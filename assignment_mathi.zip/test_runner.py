import datetime
import os
import unittest
import pandas as pd
from Test_Scripts import login
from Utility import HTMLTestRunner
from pprint import pprint


class MyTestSuite(unittest.TestCase):

    def test_suite(self):
        tests_class_1 = unittest.TestLoader().loadTestsFromTestCase(login.TestLogin)

        suite = unittest.TestSuite([tests_class_1])
        test_report_failed = open("reports/SeleniumPythonTestSummary" + "_" + str(datetime.datetime.now().strftime("%Y-%m-%d_%H.%M.%S")) + ".html", "w")
        runner = HTMLTestRunner.HTMLTestRunner(stream=test_report_failed, title='Test Report', description='Functional Tests')
        executor = runner.run(suite)
        print ("**** Error Details Below ****")
        # print '({})'.format(', '.join("'{}'".format(value) for value in executor.result))
        try:
            pprint(executor.errors[0])
        except Exception as e:
            print ("No Errors.")
        total_test_cases = len(executor.result)

        try:
            for item in range(0, total_test_cases):
                if not int(executor.result[item][0]) == 0:
                    with open('csv_files/temp.csv', 'a') as csvFile:
                        test_case_names = \
                            str(executor.result[item][1]).split('(', 1)[-1].split(')', 1)[0].split('.', 1)[-1]
                        csvFile.write(test_case_names + "\n")
                    csvFile.close()

            data_frame = pd.read_csv("csv_files/temp.csv", header=None).drop_duplicates(keep='first')
            csv_path = 'csv_files/'
            if not os.path.exists(csv_path):
                os.makedirs(csv_path)

            data_frame.to_csv(csv_path + "failed_test_classes" + "_" + str(
                datetime.datetime.now().strftime("%Y-%m-%d_%H.%M.%S")) + ".csv", index=False, header=None)
            os.remove(csv_path + "temp.csv")

        except Exception as e:
            print ('All tests passed.', e.message)


if __name__ == '__main__':
    unittest.main()
