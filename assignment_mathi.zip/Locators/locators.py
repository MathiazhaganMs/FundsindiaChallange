class Locators(object):
    login_email_textbox_xpath = "//input[@id='identifierId']"
    email_next_xpath = "//span[@class='RveJvd snByac']"
    login_password_xpath = "//input[@name='password']"
    password_next_xpath = "//div[@id='passwordNext']//span[@class='CwaK9']"
    account_username_xpath = "//h1[contains(text(),'Welcome,')]"
    account_icon_xpath = r'//*[@id="gb"]/div[2]/div[3]/div/div[2]/div/a/span'
    logout_xpath = "//a[@id='gb_71']"
    sigin_verify_xpath = "//span[contains(text(),'Choose an account')]"

