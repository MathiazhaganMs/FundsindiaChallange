from Base.environment_setup import EnvironmentSetup
from Pages.p001_pages import LoginPage


class TestLogin(EnvironmentSetup):
    def setUp(self):
        driver = self.driver
        self.page_obj = LoginPage(driver)

    def tearDown(self):
        pass

    def test_t001_login(self):
        self.assertTrue(self.page_obj.login_validation())

    def test_t002_account_name_validation(self):
        self.assertTrue(self.page_obj.account_name())

    def test_t003_account_logout(self):
        self.assertTrue(self.page_obj.logout_validation())

